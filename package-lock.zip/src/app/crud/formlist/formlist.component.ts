import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formlist',
  templateUrl: './formlist.component.html',
  styleUrls: ['./formlist.component.css']
})
export class FormlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
