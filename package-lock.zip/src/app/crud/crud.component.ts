import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-crud',
  templateUrl: './crud.component.html',
  styleUrls: ['./crud.component.css']
})
export class CrudComponent implements OnInit {

  buttonchange: string = "Add User";
  toggle: boolean = false;
  // isButtonShown:boolean=true
  constructor(private route: Router) {

  }

  ngOnInit(): void {
  }

  setroute() {
    debugger
    if (this.toggle) {
      this.toggle = false;
      this.buttonchange = 'Add User';
      this.route.navigate(['/crud/crudcompo/list']);

    }
    else {
      this.toggle = true;
      this.buttonchange = 'Back to Lists';
      this.route.navigate(['/crud/crudcompo/formcrud']);
    }
    // debugger
    // if (this.kuchbhi) {
    //   this.buttonchange = 'Add User';
    //   this.route.navigate(['crudcompo/list']);
    // }
    // else {
    //   this.buttonchange = 'Back to Lists';
    //   this.route.navigate(['crudcompo/formcrud']);
    // }
  }

}
