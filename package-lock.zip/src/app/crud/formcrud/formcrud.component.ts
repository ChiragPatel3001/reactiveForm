import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Department } from '../Model/crud.model';
import { CrudserveService } from '../services/crudserve.service';



@Component({
  selector: 'app-formcrud',
  templateUrl: './formcrud.component.html',
  styleUrls: ['./formcrud.component.css']
})
export class FormcrudComponent implements OnInit {

  MaaruForm: FormGroup;
  department: Department[]= [];
  constructor(private bob: FormBuilder, private callservice:CrudserveService) { 
    this.MaaruForm = this.maarufunction();
  }

  ngOnInit(): void {
    this.getdata();
  }
  maarufunction(): FormGroup{
     return this.bob.group({
      firstname : ['',Validators.required],
      lastname : ['',Validators.required],
      email : ['',Validators.required],
      dept : ['FrontEnd']
      

     }
     )

  }
  getdata(){
    return this.callservice.getdepartment().subscribe(
      (cruddata: Department[])=> 
      {
        this.department= cruddata;
      }
    )
  }
  onSubmit(){
    
  }
}
