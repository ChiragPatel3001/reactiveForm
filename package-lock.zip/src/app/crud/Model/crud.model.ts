export interface Department{
    id: number,
    name: string
}
export interface User{
    firstname : string,
      lastname : string,
      email : string,
      dept : string
}