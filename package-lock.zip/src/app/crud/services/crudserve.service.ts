import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Department } from '../Model/crud.model';

@Injectable({
  providedIn: 'root'
})
export class CrudserveService {

  apilink: string

  constructor(private http: HttpClient) {
    this.apilink= environment.baseURL
   }
  getdepartment():Observable<Department[]>{
    return this.http.get<Department[]>(`${this.apilink}/Department`)
  }
}
