import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CrudRoutingModule } from './crud-routing.module';
import { CrudComponent } from './crud.component';
import { FormcrudComponent } from './formcrud/formcrud.component';
import { FormlistComponent } from './formlist/formlist.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    CrudComponent,
    FormcrudComponent,
    FormlistComponent,
    
  ],
  imports: [
    CommonModule,
    CrudRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  exports:[
    FormlistComponent
  ]
})
export class CrudModule { }
